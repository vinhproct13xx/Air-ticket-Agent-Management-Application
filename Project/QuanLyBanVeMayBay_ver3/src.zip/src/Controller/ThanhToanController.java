/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.ThanhToan;
import Model.ThanhToanDAO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author hoangdang
 */
public class ThanhToanController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private JFXTextField HoTenLienHe;
    @FXML
    private JFXTextField DienThoai;
    @FXML
    private JFXTextField Email;
    @FXML
    private JFXTextField Diachi;
    @FXML
    private JFXTextField HoTenKhachHang;
    @FXML
    private JFXDatePicker NgaySinh;
    @FXML
    private JFXTextField QuocTich;
    @FXML
    private Label DiemDi;
    @FXML
    private Label DiemDen;
    @FXML
    private Label ThoiDiemXuatPhat;
    @FXML
    private Label HangBay;
    @FXML
    private Label LoaiGhe;
    @FXML
    private Label GioBay;
//    @FXML
//    private Label GioDen;
    @FXML
    private Label ThoiGianBay;
    @FXML
    private Label LoaiDuongBay;
    @FXML
    private Label SoVe;
    @FXML
    private Label TongTien;
    @FXML
    private JFXButton btnThanhToan;
    @FXML
    private JFXButton btnBack;

    private String DiemDiString;
    private String DiemDenString;
    private LocalDate NgayDiDate;
    private String HangMBString;
    private int LoaiVeInt;
    private String GioKhoiHanhString;
    private int SoLuongVeInt;
    private int GiaVeInt;
    private String MaCBString;
    private String KhachhangString;

    ThanhToanDAO thanhToanDAO = new ThanhToanDAO();
    ThanhToan tt = new ThanhToan();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//        HoTenLienHe.setText("hoang");
    }    
    @FXML
    public void handleThanhToan(ActionEvent event) throws SQLException{
        KhachhangString = this.HoTenLienHe.getText();
        tt.setGiaVeInt(GiaVeInt);
        tt.setKhachhangString(KhachhangString);
        tt.setLoaiVeInt(LoaiVeInt);
        tt.setMaCBString(MaCBString);
        
        
        thanhToanDAO.LuuThongTinVeVoDB(tt);

        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setContentText("ten khach hang: "+KhachhangString+"\n"+"tong tien phai thanh toan: "+this.TongTien);
        alert.show();
    }
    
    public double thanhtien(int loaive, int slnglon, int sltreem, int giave){
        double tongtien=0;
        if (loaive == 1) {
            tongtien = (slnglon*giave +sltreem*giave*0.7)*1.1;
        } if (loaive==0) {
            tongtien = (slnglon*giave +sltreem*giave) ;
        }
        return tongtien;
        
    }
    @FXML
    public void handleBack(ActionEvent event) throws IOException{
        AnchorPane paneChiTietChuyenBay = new AnchorPane();
        FXMLLoader fXMLLoader = MainController.getMainController().createPage(paneChiTietChuyenBay, "/View/DanhSachChuyenBay.fxml");
        paneChiTietChuyenBay.getChildren().add(paneChiTietChuyenBay); 
        GeneralFuntion.FitChildContent(paneChiTietChuyenBay);
    }
    
    public void ChuyenDuLieu(String MaCBString,String DiemDi,String DiemDen,LocalDate NgayDate, int TGBay,String HangMB,int LoaiVe,String GioKH,int SoNL,int SoTreEm, int GiaVe){
        this.DiemDi.setText(DiemDi);
        this.DiemDen.setText(DiemDen);
        this.ThoiDiemXuatPhat.setText(NgayDate.toString());
        this.HangBay.setText(HangMB);
        this.GioBay.setText(GioKH);
        this.ThoiGianBay.setText(Integer.toString(TGBay)+"h");
        if (LoaiVe==1) {
            this.LoaiGhe.setText("Thuong Gia");
        } else {this.LoaiGhe.setText("Pho Thong");}
        this.SoVe.setText(String.valueOf(SoNL+SoTreEm));
        DiemDiString = DiemDi;
        DiemDenString = DiemDen;
        NgayDiDate = NgayDate;
        this.HangMBString = HangMB;
        LoaiVeInt = LoaiVe;
        GioKhoiHanhString = GioKH;
        GiaVeInt = GiaVe;
        this.MaCBString=MaCBString;
        this.TongTien.setText(Double.toString(thanhtien(LoaiVe, SoNL, SoTreEm, GiaVe)));
    }
    
    
    
}
