/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author hoangdang
 */
public class ThanhToan {
    private int LoaiVeInt;
//    private String GioKhoiHanhString;
//    private int SoLuongVeInt;
    private int GiaVeInt;
    private String MaCBString;
    private String KhachhangString;

    public ThanhToan() {
    }

    public ThanhToan(int LoaiVeInt, int GiaVeInt, String MaCBString, String KhachhangString) {
        this.LoaiVeInt = LoaiVeInt;
        this.GiaVeInt = GiaVeInt;
        this.MaCBString = MaCBString;
        this.KhachhangString = KhachhangString;
    }

    public int getLoaiVeInt() {
        return LoaiVeInt;
    }

    public void setLoaiVeInt(int LoaiVeInt) {
        this.LoaiVeInt = LoaiVeInt;
    }

    public int getGiaVeInt() {
        return GiaVeInt;
    }

    public void setGiaVeInt(int GiaVeInt) {
        this.GiaVeInt = GiaVeInt;
    }

    public String getMaCBString() {
        return MaCBString;
    }

    public void setMaCBString(String MaCBString) {
        this.MaCBString = MaCBString;
    }

    public String getKhachhangString() {
        return KhachhangString;
    }

    public void setKhachhangString(String KhachhangString) {
        this.KhachhangString = KhachhangString;
    }
    
}
