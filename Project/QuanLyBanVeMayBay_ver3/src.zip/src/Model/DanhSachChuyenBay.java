/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.time.LocalDate;

/**
 *
 * @author hoangdang
 */
public class DanhSachChuyenBay {
    private String MaHMB;
    private String MaCB;
    private String DiemKhoiHanh;
    private String DiemDen;
    private String GioKH;
    private int TgBay;
    private double GiaVe;
    private LocalDate NgayBayDate;
    private int SLNgL;
    private int SLTreEm;
    private int LoaiVe;

    public DanhSachChuyenBay() {
    }

    public DanhSachChuyenBay(String MaHMB, String MaCB, String DiemKhoiHanh, String DiemDen, String GioKH, int TgBay, double GiaVe, LocalDate NgayBayDate, int SLNgL, int SLTreEm, int LoaiVe) {
        this.MaHMB = MaHMB;
        this.MaCB = MaCB;
        this.DiemKhoiHanh = DiemKhoiHanh;
        this.DiemDen = DiemDen;
        this.GioKH = GioKH;
        this.TgBay = TgBay;
        this.GiaVe = GiaVe;
        this.NgayBayDate = NgayBayDate;
        this.SLNgL = SLNgL;
        this.SLTreEm = SLTreEm;
        this.LoaiVe = LoaiVe;
    }
//    public void inra (){
//                System.out.println("ham in ra");
//        System.out.println(MaHMB);
//          System.out.println(MaCB);
//            System.out.println(DiemKhoiHanh);
//              System.out.println(DiemDen);
//                System.out.println(GioKH);
//                  System.out.println(TgBay);
//                    System.out.println(GiaVe);
//                      System.out.println(NgayBayDate);
//                        System.out.println(SLNgL);
//                          System.out.println(SLTreEm);
//                            System.out.println(LoaiVe);
//    }
    public String getMaHMB() {
        return MaHMB;
    }

    public void setMaHMB(String MaHMB) {
        this.MaHMB = MaHMB;
    }

    public String getMaCB() {
        return MaCB;
    }

    public void setMaCB(String MaCB) {
        this.MaCB = MaCB;
    }

    public String getDiemKhoiHanh() {
        return DiemKhoiHanh;
    }

    public void setDiemKhoiHanh(String DiemKhoiHanh) {
        this.DiemKhoiHanh = DiemKhoiHanh;
    }

    public String getDiemDen() {
        return DiemDen;
    }

    public void setDiemDen(String DiemDen) {
        this.DiemDen = DiemDen;
    }

    public String getGioKH() {
        return GioKH;
    }

    public void setGioKH(String GioKH) {
        this.GioKH = GioKH;
    }

    public int getTgBay() {
        return TgBay;
    }

    public void setTgBay(int TgBay) {
        this.TgBay = TgBay;
    }

    public double getGiaVe() {
        return GiaVe;
    }

    public void setGiaVe(double GiaVe) {
        this.GiaVe = GiaVe;
    }

    public LocalDate getNgayBayDate() {
        return NgayBayDate;
    }

    public void setNgayBayDate(LocalDate NgayBayDate) {
        this.NgayBayDate = NgayBayDate;
    }

    public int getSLNgL() {
        return SLNgL;
    }

    public void setSLNgL(int SLNgL) {
        this.SLNgL = SLNgL;
    }

    public int getSLTreEm() {
        return SLTreEm;
    }

    public void setSLTreEm(int SLTreEm) {
        this.SLTreEm = SLTreEm;
    }

    public int getLoaiVe() {
        return LoaiVe;
    }

    public void setLoaiVe(int LoaiVe) {
        this.LoaiVe = LoaiVe;
    }

    
    
   
    
    
}
